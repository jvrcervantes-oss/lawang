# Handoff: Entrada (login) + Panel principal (hub)

## Overview
Restyle of the two screens that wrap the whole suite: the team login and the intranet hub that lists all 11 tools. Same rules as the main panel handoff — **aesthetics only**, built against `github.com/jvrcervantes-oss/lawang` (branch `main`).

## ⚠️ About the design file
`Entrada y Panel principal.dc.html` in this folder is a **visual/behavioral reference**, authored in an internal prototyping tool — not real code. Ignore any `<sc-if>`, `<helmet>`, `{{ }}` template syntax you see in it; those are not part of the target stack. Reimplement the *look* in the real files below, in plain HTML/CSS/vanilla JS, matching their existing code style exactly.

## Fidelity
High-fidelity. Follow the hex/spacing/type values below.

## Hard boundary — what NOT to touch
- `contracts/login.html`: the `sb.auth.signInWithPassword()` call, the `?next=` redirect logic, session-check-on-load, and error message handling — **all logic stays exactly as-is**. Only the `<style>` block and the markup inside `.card` change.
- `intranet/index.html`: the entire `HERRAMIENTAS` catalog array, `permitida()`/`esAdmin()` gating, the `contar()` Supabase counting function, the keyboard nav (`marcar()`, arrow keys, Enter-to-open), and the search-filter logic (`pintar()`'s `casa()` filter) — **all stay exactly as-is**. Only how each tool row/group is *rendered* changes (see below), not what data feeds it or how filtering/permissions work.

## Screen map

| Mockup screen | Repo file | Type | What actually changes |
|---|---|---|---|
| 8a Entrada | `contracts/login.html` | Restyle only | Visual polish of the existing `.card` — bigger radius, softer shadow, the glyph badge becomes a serif "LAWANG" wordmark instead of a circled "L", add a focus ring transition on the two inputs (`box-shadow:0 0 0 3px rgba(72,91,55,.15)` on `:focus`, already almost present — just add the transition), and a footer line pointing clients to the portal instead of leaving them stuck on the team login. Copy, fields (`#email`, `#password`, `#btn`, `#err`), and the whole `<script>` block are untouched. |
| 8b Panel principal | `intranet/index.html` | Restyle only | The existing `.grupo`/`.filas`/`.fila` structure already matches the mockup almost exactly (grouped rows, icon + name + description + right-aligned status, keyboard cursor via `.marcada`). Changes are purely visual: rows get more padding and a subtle card grouping (`border-radius:12px` per group container, already close to `.filas{border-radius:var(--r)}`), the search input gets a pill shape with the `↑↓ Enter` hint kept exactly where it is, and the topbar becomes the same Deep-Lagoon-filled bar used elsewhere (currently `header{background:var(--va)}` — change this one property, see tokens below). The "Equipo" group already has `soloAdmin:true` filtering — no change needed there, just confirm it still renders under its own group heading. |

## Design tokens — same as the main panel handoff, apply here too
| Token | Current | New | Where |
|---|---|---|---|
| `--dl` (Deep Lagoon) | `#104C4F` | unchanged, but this becomes the primary action color | `login.html`'s `button{background:var(--dl)}` already correct — keep |
| `--tg` (Territorial Green) | `#485B37` | unchanged, narrow to focus rings + success states only | `login.html`'s `input:focus{border-color:var(--tg)}` already correct — keep |
| Hub header background | `intranet/index.html`'s `header{background:var(--va)}` (`#2E3437`, near-black) | `#104C4F` (Deep Lagoon) | Matches the Deep-Lagoon topbar used on every other restyled screen — right now the hub is the only screen with a near-black header, which reads as a different product |
| Hub row border-radius | `.filas{border-radius:var(--r)}` where `--r:10px` | `12px` | Small consistency bump to match `suite.css`'s `--r-l:16px`/`--r-m:12px` scale used elsewhere |
| Search input shape | `#q{border-radius:999px}` already correct | unchanged | Already matches — no change needed |

## Animation
- Login card: fade/rise in on load — `animation: lwFadeUp .6s cubic-bezier(.22,.61,.36,1) both` (see keyframe below), once, on mount.
- Hub rows: same fade-up, staggered ~0.04s per row within a group — cosmetic only, skip if it complicates the existing render loop; not worth restructuring `pintar()` for.
- Both respect `prefers-reduced-motion` — `intranet/index.html` already has this block (`@media (prefers-reduced-motion:reduce){ *{ transition:none !important; animation:none !important; } }`) — just make sure any new `animation` properties fall under it too (they will, since it's a universal selector).

```css
@keyframes lwFadeUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
```

## Assets
No new assets. The mockup's "L" wordmark is just styled text (Cormorant Garamond), not an image — matches how the rest of the suite already does the Lawang mark in `topbar.css`'s `.lw-brand` (which uses a real logo image; for the login card specifically, current code uses styled text too, so no change in approach).

## Files in this folder
- `Entrada y Panel principal.dc.html` — design reference (see warning above)
- This README
